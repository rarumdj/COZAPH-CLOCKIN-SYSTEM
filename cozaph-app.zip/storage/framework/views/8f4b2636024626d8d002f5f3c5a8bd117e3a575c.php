<?php $__env->startComponent('mail::message'); ?>
<div class="mb-5 w-100 text-center">
    <h1>Good Day sir,</h1>
    <p>Details of service report from <?php echo e($body['date']); ?>.</p>
</div>

<div class="p-5 text-center">
    <?php $__env->startComponent('mail::panel'); ?>
    <p>Total Workers: <?php echo e($body['co_members']); ?></p>
    <?php if (isset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c)): ?>
<?php $component = $__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c; ?>
<?php unset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
</div>
<div class="p-5 text-center">
    <?php $__env->startComponent('mail::panel'); ?>
    <p>Present (Early): <?php echo e($body['co_early']); ?></p>
    <?php if (isset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c)): ?>
<?php $component = $__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c; ?>
<?php unset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
</div>
<div class="p-5 text-center">
    <?php $__env->startComponent('mail::panel'); ?>
    <p>Present (Late): <?php echo e($body['co_late']); ?></p>
    <?php if (isset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c)): ?>
<?php $component = $__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c; ?>
<?php unset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
</div>
<div class="p-5 text-center">
    <?php $__env->startComponent('mail::panel'); ?>
    <p>Absent: <?php echo e($body['co_absent']); ?></p>
    <?php if (isset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c)): ?>
<?php $component = $__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c; ?>
<?php unset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
</div>
Thanks and Regards!<br>
<?php echo e(config('app.name')); ?><br>
COZA Admin.
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Users\Rarum DJ\Documents\laravel-projects\cozaph-app\resources\views/emails/report-mail.blade.php ENDPATH**/ ?>