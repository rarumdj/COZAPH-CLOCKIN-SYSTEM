<div class="d-flex justify-content-between">

    
    <div class="ml-auto">
        <form action="<?php echo e(route('search.date')); ?>">
            <div class="col-12 col-sm-12 showcase_content_area  py-0 ">
                <div class="demo-wrapper">
                    <div id="datepicker-popup" class="input-group date datepicker">
                        <input type="text" name="date" value="<?php echo e($date); ?>" class="form-control bg-white"
                            placeholder="Set Date" />
                        <span class="input-group-addon input-group-append"><span
                                class="mdi mdi-calendar input-group-text bg-white"></span></span>
                    </div>
                </div>
            </div>
    </div>
    <div class="">
        <div class="col-12 col-sm-12 py-1">
            <button type="submit" class="form-control bg-info text-white">Search</button>
        </div>
    </div>
    </form>
</div><?php /**PATH C:\Users\Rarum DJ\Documents\laravel-projects\cozaph-app\resources\views/livewire/change-date-component.blade.php ENDPATH**/ ?>