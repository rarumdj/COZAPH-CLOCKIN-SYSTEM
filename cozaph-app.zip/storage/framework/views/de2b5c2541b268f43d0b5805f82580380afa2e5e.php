<div class="page-content-wrapper-inner">
    <div class="content-viewport">
        <div class="row">
            <div class="col-12 py-5">
                <h4>Dashboard</h4>
                <p class="text-gray">Welcome!</p>
            </div>
            <div class="col-lg-12">
                <div class=" py-3">
                    <div class="d-flex justify-content-between">
                        <div class="ml-auto">
                            <div class="col-12 col-sm-12 py-1">
                                <a href="#" class="form-control bg-info text-white" type="button"
                                    onclick="confirm('Are you sure you want to send these report?') || event.stopImmediatePropagation()"
                                    wire:click="sendReport()">
                                    Send Report
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="grid py-3">

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('change-date-component')->html();
} elseif ($_instance->childHasBeenRendered('yxq1TDl')) {
    $componentId = $_instance->getRenderedChildComponentId('yxq1TDl');
    $componentTag = $_instance->getRenderedChildComponentTagName('yxq1TDl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yxq1TDl');
} else {
    $response = \Livewire\Livewire::mount('change-date-component');
    $html = $response->html();
    $_instance->logRenderedChild('yxq1TDl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                </div>
            </div>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('summary-record-component', [])->html();
} elseif ($_instance->childHasBeenRendered('1CuT71r')) {
    $componentId = $_instance->getRenderedChildComponentId('1CuT71r');
    $componentTag = $_instance->getRenderedChildComponentTagName('1CuT71r');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1CuT71r');
} else {
    $response = \Livewire\Livewire::mount('summary-record-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('1CuT71r', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dasboard-table-component', [])->html();
} elseif ($_instance->childHasBeenRendered('6zobPbH')) {
    $componentId = $_instance->getRenderedChildComponentId('6zobPbH');
    $componentTag = $_instance->getRenderedChildComponentTagName('6zobPbH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6zobPbH');
} else {
    $response = \Livewire\Livewire::mount('dasboard-table-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('6zobPbH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pie-chart-component', [])->html();
} elseif ($_instance->childHasBeenRendered('sMcozaD')) {
    $componentId = $_instance->getRenderedChildComponentId('sMcozaD');
    $componentTag = $_instance->getRenderedChildComponentTagName('sMcozaD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('sMcozaD');
} else {
    $response = \Livewire\Livewire::mount('pie-chart-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('sMcozaD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</div>

<!-- DATA MODAL -->
<div class="modal fade bd-example-modal-lg" id="teamUser" tabindex="-1" role="dialog" aria-labelledby="teamUserLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h5 class="modal-title" id="memberLable">Member Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <!-- Modal body -->
            <!-- <div class="modal-body" id="members_detail"> -->

            <!-- </div> -->
            <div class="modal-body" id="viewMember">

            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Rarum DJ\Documents\laravel-projects\cozaph-app\resources\views/livewire/dated-dashboard-component.blade.php ENDPATH**/ ?>