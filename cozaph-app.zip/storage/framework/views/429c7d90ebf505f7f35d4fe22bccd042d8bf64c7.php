<?php $__env->startComponent('mail::message'); ?>
<div class="mb-5 w-100 text-center">
    <h1>Hello <?php echo e($body['name']); ?>,</h1>
    <p>Your registration was successfull! Below is your REG ID for clockin.</p>
    <div class="p-5 text-center">
        <?php $__env->startComponent('mail::panel'); ?>
        <?php echo e($body['user_id']); ?>

        <?php if (isset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c)): ?>
<?php $component = $__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c; ?>
<?php unset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    </div>
</div>
Thanks and Regards!<br>
<?php echo e(config('app.name')); ?><br>
COZA Admin.
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Users\Rarum DJ\Documents\laravel-projects\cozaph-app\resources\views/registration-mail.blade.php ENDPATH**/ ?>