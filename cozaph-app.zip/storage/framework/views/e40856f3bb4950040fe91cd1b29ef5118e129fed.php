<div class="row">
    <div class="col-lg-4 col-md-6 equel-grid">
        <div class="grid">
            <div class="grid-body">
                <h2 class="grid-title">Attendance Chart</h2>
                <div class="item-wrapper">
                    <div class="sample-chart">
                        <?php if(!is_null($pieChartModel)): ?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('livewire-pie-chart', ['pieChartModel' => $pieChartModel])->html();
} elseif ($_instance->childHasBeenRendered(''.e($pieChartModel->reactiveKey()).'')) {
    $componentId = $_instance->getRenderedChildComponentId(''.e($pieChartModel->reactiveKey()).'');
    $componentTag = $_instance->getRenderedChildComponentTagName(''.e($pieChartModel->reactiveKey()).'');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(''.e($pieChartModel->reactiveKey()).'');
} else {
    $response = \Livewire\Livewire::mount('livewire-pie-chart', ['pieChartModel' => $pieChartModel]);
    $html = $response->html();
    $_instance->logRenderedChild(''.e($pieChartModel->reactiveKey()).'', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        <?php endif; ?>
                    </div>
                    
                    
                </div>
            </div>
            <div class="px-4 py-3 d-block">
                
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Rarum DJ\Documents\laravel-projects\cozaph-app\resources\views/livewire/pie-chart-component.blade.php ENDPATH**/ ?>