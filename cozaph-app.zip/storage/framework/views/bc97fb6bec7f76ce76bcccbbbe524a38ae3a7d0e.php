<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>COZA - Web App</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/iconfonts/mdi/css/materialdesignicons.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/css/vendor.addons.css')); ?>" />
    <!-- endinject -->
    <!-- vendor css for this page -->
    <!-- End vendor css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/shared/style.css')); ?>" />
    <!-- endinject -->
    <!-- Layout style -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/demo_1/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/toastr.css')); ?>" />
    <!-- Layout style -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet" />
    <?php echo $__env->yieldContent('styles'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body class="header-fixed">
    <!-- partial:partials/_header.html -->
    <nav class="t-header">
        <div class="t-header-brand-wrapper">
            <a href="index.html">
                <img class="logo" src="<?php echo e(asset('assets/images/logo.svg')); ?>" alt="">
                <img class="logo-mini" src="<?php echo e(asset('assets/images/logo_mini.svg')); ?>" alt="">
            </a>
            <button class="t-header-toggler t-header-desk-toggler d-none d-lg-block">
                <svg class="logo" viewBox="0 0 200 200">
                    <path class="top" d="
                M 40, 80
                C 40, 80 120, 80 140, 80
                C180, 80 180, 20  90, 80
                C 60,100  30,120  30,120
              "></path>
                    <path class="middle" d="
                M 40,100
                L140,100
              "></path>
                    <path class="bottom" d="
                M 40,120
                C 40,120 120,120 140,120
                C180,120 180,180  90,120
                C 60,100  30, 80  30, 80
              "></path>
                </svg>
            </button>
        </div>
        <div class="t-header-content-wrapper">
            <div class="t-header-content">
                <button class="t-header-toggler t-header-mobile-toggler d-block d-lg-none">
                    <i class="mdi mdi-menu"></i>
                </button>
                <form action="#" class="t-header-search-box">
                    <div class="input-group">
                        <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="Search"
                            autocomplete="off">
                        <button class="btn btn-primary" type="submit"><i class="mdi mdi-arrow-right-thick"></i></button>
                    </div>
                </form>
                
        </div>
        </div>
    </nav>
    <!-- partial -->
    <div class="page-body">
        <!-- partial:partials/_sidebar.html -->
        <div class="sidebar">
            <div class="user-profile">
                <div class="display-avatar animated-avatar">
                    <img class="profile-img img-lg rounded-circle"
                        src="<?php echo e(asset('assets/images/profile/male/image_1.png')); ?>" alt="profile image">
                </div>
                <div class="info-wrapper">
                    
                    
                </div>
            </div>
            <ul class="navigation-menu">
                <li class="nav-category-divider">MAIN</li>
                <li>
                    <a href="/">
                        <span class="link-title">Dashboard</span>
                        <i class="mdi mdi-gauge link-icon"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('worker.register')); ?>">
                        <span class="link-title">Workforce</span>
                        <i class="mdi mdi-clipboard-outline link-icon"></i>
                    </a>
                </li>
                <li>
                    <a href="#sample-pages" data-toggle="collapse" aria-expanded="false">
                        <span class="link-title">Attendance</span>
                        <i class="mdi mdi-clock-outline link-icon"></i>
                    </a>
                    <ul class="collapse navigation-submenu" id="sample-pages">
                        <li>
                            <a href="<?php echo e(route('worker.clockin')); ?>" target="">Clock in</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('worker.clockout')); ?>" target="">Clock out</a>
                        </li>
                    </ul>
                </li>

                <li>
                    <a href="<?php echo e(route('mail.dashboard')); ?>">
                        <span class="link-title">Mailer</span>
                        <i class="mdi mdi-email-outline link-icon"></i>
                    </a>
                </li>
                
            </ul>
        </div>
        <!-- partial -->
        <div class="page-content-wrapper">



            <?php echo e($slot); ?>

            <?php echo $__env->yieldContent('content'); ?>



            <!-- partial-->
            <footer class="footer">
                <div class="row">
                    <div class="col-sm-6 text-center text-sm-right order-sm-1">
                        <ul class="text-gray">
                            <li><a href="#">Terms of use</a></li>
                            <li><a href="#">Privacy Policy</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 text-center text-sm-left mt-3 mt-sm-0">
                        <small class="text-muted d-block">Copyright © 2019 <a>COZA</a>. All rights reserved</small>
                        
                    </div>
                </div>
            </footer>
            <!-- partial -->
        </div>
        <!-- page content ends -->
    </div>
    <!--page body ends -->
    <!-- SCRIPT LOADING START FORM HERE /////////////-->
    <!-- plugins:js -->
    <script src="<?php echo e(asset('assets/vendors/js/core.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/js/vendor.addons.js')); ?>"></script>
    <!-- endinject -->
    <!-- Vendor Js For This Page Ends-->
    <script src="<?php echo e(asset('assets/vendors/apexcharts/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/chartjs/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/charts/chartjs.addon.js')); ?>"></script>
    <!-- Vendor Js For This Page Ends-->
    <script src="<?php echo e(asset('assets/vendors/d3/d3.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/c3/c3.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
    <!-- endbuild -->
    <script src="<?php echo e(asset('assets/js/summernote-lite.min')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/tinymce/tinymce.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/toastr.js')); ?>"></script>
    

    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="http://127.0.0.1:8000/vendor/livewire-charts/app.js"></script>
    <script src="<?php echo e(asset('assets/js/alpinejs-3.3.1.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('scripts'); ?>
    <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html><?php /**PATH C:\Users\Rarum DJ\Documents\laravel-projects\cozaph-app\resources\views/layouts/base.blade.php ENDPATH**/ ?>