
<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper-inner">
    <div class="content-viewport">
        <div class="row">
            <div class="col-12 py-5">
                <h4>Dashboard</h4>
                <p class="text-gray">Welcome, Allen Clerk</p>
            </div>
            <div class="col-lg-12">
                <div class=" py-3">
                    <div class="d-flex justify-content-between">
                        <div class="ml-auto">
                            <div class="col-12 col-sm-12 py-1">
                                <input type="button" class="form-control bg-info text-white" value="Send Report" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="grid py-3">

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('change-date-component')->html();
} elseif ($_instance->childHasBeenRendered('rOWqG7l')) {
    $componentId = $_instance->getRenderedChildComponentId('rOWqG7l');
    $componentTag = $_instance->getRenderedChildComponentTagName('rOWqG7l');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rOWqG7l');
} else {
    $response = \Livewire\Livewire::mount('change-date-component');
    $html = $response->html();
    $_instance->logRenderedChild('rOWqG7l', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


                </div>
            </div>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('summary-record-component')->html();
} elseif ($_instance->childHasBeenRendered('Hz1v6pK')) {
    $componentId = $_instance->getRenderedChildComponentId('Hz1v6pK');
    $componentTag = $_instance->getRenderedChildComponentTagName('Hz1v6pK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Hz1v6pK');
} else {
    $response = \Livewire\Livewire::mount('summary-record-component');
    $html = $response->html();
    $_instance->logRenderedChild('Hz1v6pK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>




        
        
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dasboard-table-component')->html();
} elseif ($_instance->childHasBeenRendered('IRgvZAe')) {
    $componentId = $_instance->getRenderedChildComponentId('IRgvZAe');
    $componentTag = $_instance->getRenderedChildComponentTagName('IRgvZAe');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('IRgvZAe');
} else {
    $response = \Livewire\Livewire::mount('dasboard-table-component');
    $html = $response->html();
    $_instance->logRenderedChild('IRgvZAe', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        


        <div class="row">
            <div class="col-lg-4 col-md-6 equel-grid">
                <div class="grid">
                    <div class="grid-body">
                        <h2 class="grid-title">Attendance Chart</h2>
                        <div class="item-wrapper">
                            <div id="sample_c3-pie-chart" class="sample-chart"></div>
                        </div>
                    </div>
                    <div class="px-4 py-3 d-block">
                        <div class="row">
                            <div class="col text-center" id="countAttend">

                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- DATA MODAL -->
<div class="modal fade bd-example-modal-lg" id="teamUser" tabindex="-1" role="dialog" aria-labelledby="teamUserLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h5 class="modal-title" id="memberLable">Member Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <!-- Modal body -->
            <!-- <div class="modal-body" id="members_detail"> -->

            <!-- </div> -->
            <div class="modal-body" id="viewMember">

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rarum DJ\Documents\laravel-projects\cozaph-app\resources\views/dashboard.blade.php ENDPATH**/ ?>