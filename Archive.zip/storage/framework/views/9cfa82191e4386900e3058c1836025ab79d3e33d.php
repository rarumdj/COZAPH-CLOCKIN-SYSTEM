<?php $__env->startComponent('mail::message'); ?>
<div class="mb-5 w-100 text-center">
    <h1>Hello <?php echo e($body['name']); ?>,</h1>
    <p>Your registration was successfull! Below is your REG ID for clockin.</p>
</div>

<div class="p-5 text-center">
    <?php $__env->startComponent('mail::panel'); ?>
    <?php echo e($body['user_id']); ?>

    <?php echo $__env->renderComponent(); ?>
</div>
Thanks and Regards!<br>
<?php echo e(config('app.name')); ?><br>
<?php echo e(config('app.name')); ?> Admin.
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/rarumdj/Documents/Laravel/christheaven/resources/views/emails/registration-mail.blade.php ENDPATH**/ ?>