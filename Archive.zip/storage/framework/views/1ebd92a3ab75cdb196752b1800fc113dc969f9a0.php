<?php $__env->startSection('title'); ?> <?php echo e('Dashboard'); ?> <?php $__env->stopSection(); ?>
<div class="page-content-wrapper-inner">
    <div class="content-viewport">
        <div class="row">
            <div class="col-12 py-5">
                <h4>Dashboard</h4>
                <p class="text-gray">Welcome!</p>
            </div>
            <div class="col-lg-12">
                <div class=" py-3">
                    <div class="d-flex justify-content-between">
                        <div class="ml-auto">
                            <div class="col-12 col-sm-12 py-1">
                                <a href="#" class="form-control bg-info text-white" type="button"
                                    onclick="confirm('Are you sure you want to send these report?') || event.stopImmediatePropagation()"
                                    wire:click="sendReport()">
                                    Send Report
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="grid py-3">

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('change-date-component')->html();
} elseif ($_instance->childHasBeenRendered('l1230812917-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1230812917-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1230812917-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1230812917-0');
} else {
    $response = \Livewire\Livewire::mount('change-date-component');
    $html = $response->html();
    $_instance->logRenderedChild('l1230812917-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                </div>
            </div>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('summary-record-component', [])->html();
} elseif ($_instance->childHasBeenRendered('l1230812917-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1230812917-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1230812917-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1230812917-1');
} else {
    $response = \Livewire\Livewire::mount('summary-record-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1230812917-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dasboard-table-component', [])->html();
} elseif ($_instance->childHasBeenRendered('l1230812917-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l1230812917-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1230812917-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1230812917-2');
} else {
    $response = \Livewire\Livewire::mount('dasboard-table-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1230812917-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pie-chart-component', [])->html();
} elseif ($_instance->childHasBeenRendered('l1230812917-3')) {
    $componentId = $_instance->getRenderedChildComponentId('l1230812917-3');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1230812917-3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1230812917-3');
} else {
    $response = \Livewire\Livewire::mount('pie-chart-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1230812917-3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</div>

<!-- DATA MODAL -->
<div class="modal fade bd-example-modal-lg" id="teamUser" tabindex="-1" role="dialog" aria-labelledby="teamUserLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h5 class="modal-title" id="memberLable">Member Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <!-- Modal body -->
            <!-- <div class="modal-body" id="members_detail"> -->

            <!-- </div> -->
            <div class="modal-body" id="viewMember">

            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('script'); ?>
<script>
    window.livewire.on('alert', param => {
    toastr[param['type']](param['message']);
});
</script>
<?php $__env->stopPush(); ?><?php /**PATH /Users/rarumdj/Documents/Laravel/christheaven/resources/views/livewire/dated-dashboard-component.blade.php ENDPATH**/ ?>