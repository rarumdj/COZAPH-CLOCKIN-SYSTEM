<?php $__env->startSection('title'); ?> <?php echo e('Register Worker'); ?> <?php $__env->stopSection(); ?>

<div class="page-content-wrapper-inner">
    <div class="viewport-header">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb has-arrow">
                <li class="breadcrumb-item"><a href="/">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Register new worker</li>
            </ol>
        </nav>
    </div>
    <div class="content-viewport">

        <?php if($newWorker): ?>
        <div class="row">
            <div class="col-md-12">
                <div class="align-items-center justify-content-between d-flex flex-column">
                    <img src="<?php echo e(asset('assets/images/checked.png')); ?>" alt="">
                    <h5 class="mt-3">Registration success</h5>
                    <h6 class="mt-4">
                        Dear <?php echo e($newWorker->firstname.' '.$newWorker->lastname); ?>,
                    </h6>
                    <p>Your registration was successful, here is your clockin ID
                        <strong><?php echo e($newWorker->user_id); ?></strong>. A copy of
                        your ID was also sent to
                        your mail.
                    </p>
                    <p>Thanks, Regards</p>
                </div>
            </div>
        </div>

        <?php else: ?>

        <div class="row">
            <div class="col-lg-12">
                <div class="grid">
                    <div class="grid-header">
                        <div class="col-md-12">

                            <div class="align-items-center justify-content-between d-flex">
                                <div>
                                    Register Worker
                                </div>
                                <div class="ml-auto showcase_row_area">
                                    <div class="col-md-9 showcase_content_area">
                                        <a href="<?php echo e(route('worker.view')); ?>" class="btn btn-primary">
                                            View Workers
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="grid-body">
                        <div class="item-wrapper">
                            <div class="row mb-3">
                                <div class="col-md-8 mx-auto">
                                    <form wire:submit.prevent="storeWorker" enctype="multipart/form-data">
                                        <div class="form-group row showcase_row_area">
                                            <div class="col-md-3 showcase_text_area">
                                                <label>First Name</label>
                                            </div>
                                            <div class="col-md-9 showcase_content_area">
                                                <input type="text" class="form-control" id="" placeholder="First Name"
                                                    wire:model="firstname" required />
                                            </div>
                                        </div>
                                        <div class="form-group row showcase_row_area">
                                            <div class="col-md-3 showcase_text_area">
                                                <label>Last Name</label>
                                            </div>
                                            <div class="col-md-9 showcase_content_area">
                                                <input type="text" class="form-control" id="" placeholder="Last Name"
                                                    wire:model="lastname" required />
                                            </div>
                                        </div>
                                        <div class="form-group row showcase_row_area">
                                            <div class="col-md-3 showcase_text_area">
                                                <label for="inputType13">Department</label>
                                            </div>
                                            <div class="col-md-9 showcase_content_area">
                                                <select class="form-control" wire:model="department" required>
                                             <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value=<?php echo e($department->name); ?>><?php echo e($department->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row showcase_row_area">
                                            <div class="col-md-3 showcase_text_area">
                                                <label for="inputType13">Role</label>
                                            </div>
                                            <div class="col-md-9 showcase_content_area">
                                                <select class="form-control" wire:model="role" required>
                                                    <option value="Member">Member</option>
                                                    <option value="Leader">Leader</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row showcase_row_area">
                                            <div class="col-md-3 showcase_text_area">
                                                <label>Email</label>
                                            </div>
                                            <div class="col-md-9 showcase_content_area">
                                                <input type="email" class="form-control" placeholder="mail@email.com"
                                                    wire:model="email" required />
                                            </div>
                                        </div>
                                        <div class="form-group row showcase_row_area">
                                            <div class="col-md-3 showcase_text_area">
                                                <label>Phone</label>
                                            </div>
                                            <div class="col-md-9 showcase_content_area">
                                                <input type="text" class="form-control" placeholder="08090000000"
                                                    wire:model="phone"
                                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"
                                                    required />
                                            </div>
                                        </div>
                                        <div class="form-group row showcase_row_area">
                                            <div class="col-md-3 showcase_text_area">
                                                <label>Marital Status</label>
                                            </div>
                                            <div class="col-md-9 showcase_content_area">
                                                <select class="form-control" wire:model="m_status" required>
                                                    <option value="Single">Single</option>
                                                    <option value="Married">
                                                        Married
                                                    </option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row showcase_row_area">
                                            <div class="col-md-3 showcase_text_area">
                                                <label>Birthday</label>
                                            </div>
                                            <div class="col-md-9 showcase_content_area">
                                                <div id="datepicker-popup" class="input-group date datepicker">
                                                    <input type="text" class="form-control" wire:model="b_day"
                                                        onchange="this.dispatchEvent(new InputEvent('input'))"
                                                        placeholder="Date" />
                                                    <span class="input-group-addon input-group-append"><span
                                                            class="mdi mdi-calendar input-group-text"></span></span>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="form-group row showcase_row_area">
                                            <div class="col-md-3 showcase_text_area">
                                                <label></label>
                                            </div>
                                            <div class="col-md-9 showcase_content_area">
                                                <button type="submit" class="btn btn-sm btn-primary">
                                                    Register
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->startPush('script'); ?>
<script>
    window.livewire.on('alert', param => {
    toastr[param['type']](param['message']);
});
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH /Users/rarumdj/Documents/Laravel/christheaven/resources/views/livewire/register-worker.blade.php ENDPATH**/ ?>