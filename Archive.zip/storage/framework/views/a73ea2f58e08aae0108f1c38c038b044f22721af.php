<div class="row">
    <div class="col-lg-12">
        <div class="grid">
            <div class="border-bottom px-3 py-3 d-block">
                Attendance Report
            </div>
            <?php if($checked): ?>

            <div class="border-bottom bg-inverse-secondary px-3 py-3 d-block d-flex justify-content-between">
                
                <div class="ml-auto">
                    <div class="col-12 col-sm-12 showcase_content_area mb-2 pl-1">
                        <input type="button" class="form-control bg-white"
                            onclick="confirm('Are you sure you want to Download these Records?') || event.stopImmediatePropagation()"
                            wire:click="download()" value="Download" />
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="grid-body">
                <div class="item-wrapper">
                    <div class="d-flex justify-content-between row align-content-center mb-2">
                        <div>
                            <div class="col-12 col-md-12 d-flex align-items-center mb-2">
                                <label for="paginate" class="text-nowrap mr-2 mb-0">Show</label>
                                <select wire:model="paginate" name="paginate" id="paginate"
                                    class="form-control form-control-sm">
                                    <option value="10">10</option>
                                    <option value="20">20</option>
                                    <option value="30">30</option>
                                </select>
                            </div>
                        </div>
                        <div>
                            <div class="col-12 col-md-12 d-flex align-items-center  mb-2">
                                <label for="Dept" class="text-nowrap mr-2 mb-0">Dept</label>
                                <select class="form-control form-control-sm" wire:model="selectedDept">
                                    <option value="">Dept</option>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value=<?php echo e($department->name); ?>><?php echo e($department->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div>
                            <div class="col-12 col-md-12 d-flex align-items-center  mb-2">
                                <label for="status" class="text-nowrap mr-2 mb-0">Status</label>
                                <select class="form-control form-control-sm" wire:model="selectedStatus">
                                    <option value="">Status</option>
                                    <option value="Early">Early</option>
                                    <option value="Late">Late</option>
                                    <option value="Absent">Absent</option>
                                </select>
                            </div>
                        </div>

                        

                        <div class="">
                            <div class="col-md-12 col-12 mb-2">
                                <input type="search" wire:model.debounce.500ms="search" class="form-control"
                                    placeholder="Search...">
                            </div>
                        </div>

                        <?php if($selectPage): ?>
                        <div class="col-md-10 mb-2">
                            <?php if($selectAll): ?>
                            <div>
                                You have selected all <strong><?php echo e($attendances->total()); ?></strong> items.
                            </div>
                            <?php else: ?>
                            <div>
                                You have selected <strong><?php echo e(count($checked)); ?></strong> items, Do you want to
                                Select All
                                <strong><?php echo e($attendances->total()); ?></strong>?
                                <a href="#" class="ml-2" wire:click="selectAll">Select All</a>
                            </div>
                            <?php endif; ?>

                        </div>
                        <?php endif; ?>


                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover" width="100%">
                            <thead>
                                <tr>
                                    <th><input type="checkbox" wire:model="selectPage" <?php if(!is_null($attendances) &&
                                            $attendances->isEmpty()): ?>
                                        disabled
                                        <?php endif; ?>>
                                    </th>
                                    <th>Worker</th>
                                    <th>Reg ID</th>
                                    <th>Clocked in</th>
                                    <th>Clocked out</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(!is_null($attendances)): ?>
                                <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="<?php if($this->isChecked($attendance->id)): ?>
                                    table-primary
                                <?php endif; ?>">
                                    <td><input type="checkbox" value="<?php echo e($attendance->id); ?>" wire:model="checked">
                                    </td>
                                    <td class="d-flex align-items-center border-top-0">
                                        <img class="profile-img img-sm img-rounded mr-2"
                                            src="<?php echo e(asset('assets/images/profile/male/image_1.png')); ?>"
                                            alt="profile image" />
                                        <span><?php echo e($attendance->fullname); ?>

                                            <br />
                                            <?php echo e($attendance->department); ?></span>
                                    </td>
                                    <td><?php echo e($attendance->user_id); ?></td>
                                    <td><?php echo e($attendance->clockin ? date('h:i a', strtotime($attendance->clockin)) : ''); ?>

                                    </td>
                                    <td><?php echo e($attendance->clockout ? date('h:i a', strtotime($attendance->clockout)) : ''); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>


                        </table>
                    </div>
                    <div class="row mt-4">
                        <div class="col-sm-6 offset-5">
                            <?php if(!is_null($attendances)): ?>
                            <?php echo e($attendances->links()); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Users/rarumdj/Documents/Laravel/christheaven/resources/views/livewire/dasboard-table-component.blade.php ENDPATH**/ ?>