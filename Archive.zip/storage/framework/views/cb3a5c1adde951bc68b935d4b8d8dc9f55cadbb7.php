<?php $__env->startComponent('mail::message'); ?>
<div class="mb-5 w-100 text-center">
    <h1>Dear <?php echo e($body['name']); ?>,</h1>
    <p>Your registration was successfull! Below is your email and password.</p>
</div>

<div class="p-5 text-center">
    <?php $__env->startComponent('mail::panel'); ?>
    <p>Email: <?php echo e($body['email']); ?> </p>
    <?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('mail::panel'); ?>
    <p>Password: <?php echo e($body['password']); ?> </p>
    <?php echo $__env->renderComponent(); ?>
</div>
Thanks and Regards!<br>
<?php echo e(config('app.name')); ?><br>
<?php echo e(config('app.name')); ?> Admin.
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/rarumdj/Documents/Laravel/christheaven/resources/views/emails/admin-mail.blade.php ENDPATH**/ ?>