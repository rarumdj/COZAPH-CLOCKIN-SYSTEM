<div class="row">
    <div class="col-lg col-md-6 col-sm-6 equel-grid">
        <div class="grid">
            <div class="grid-body text-gray">
                <div class="d-flex justify-content-center">


                    <p>Total Workers</p>
                </div>
                <?php if(!is_null($co_members)): ?>
                <h5 class="my-3 text-center">
                    <?php echo e($co_members); ?>

                </h5>
                <?php else: ?>
                <h5 class="my-3 text-center">
                    0
                </h5>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-lg col-md-6 col-sm-6 equel-grid">
        <div class="grid">
            <div class="grid-body text-gray">
                <div class="d-flex justify-content-center">


                    <p>Present (Early)</p>
                </div>
                <?php if(!is_null($co_early)): ?>
                <h5 class="my-3 text-center"><?php echo e($co_early); ?></h5>
                <?php else: ?>
                <h5 class="my-3 text-center">0</h5>
                <?php endif; ?>

            </div>
        </div>
    </div>
    <div class="col-lg col-md-6 col-sm-6 equel-grid">
        <div class="grid">
            <div class="grid-body text-gray">
                <div class="d-flex justify-content-center">


                    <p>Present (Late)</p>
                </div>

                <?php if(!is_null($co_late)): ?> <h5 class="my-3 text-center"><?php echo e($co_late); ?></h5>
                <?php else: ?>
                <h5 class="my-3 text-center">0</h5>
                <?php endif; ?>

            </div>
        </div>
    </div>
    <div class="col-lg col-md-6 col-sm-6 equel-grid">
        <div class="grid">
            <div class="grid-body text-gray">
                <div class="d-flex justify-content-center">


                    <p>Absent</p>
                </div>
                <?php if(!is_null($co_absent)): ?>
                <h5 class="my-3 text-center"><?php echo e($co_absent); ?></h5>
                <?php else: ?>
                <h5 class="my-3 text-center">0</h5>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div><?php /**PATH /Users/rarumdj/Documents/Laravel/christheaven/resources/views/livewire/summary-record-component.blade.php ENDPATH**/ ?>